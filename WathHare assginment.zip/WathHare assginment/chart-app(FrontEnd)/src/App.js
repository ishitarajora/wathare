import React, { useState, useEffect } from "react";
import axios from "axios";
import { BarChart, Bar, PieChart, Pie, ScatterChart, Scatter, LineChart, Line, Cell, Table, Tooltip } from "recharts";
import "./style.css";

const API_URL = "http://localhost:3000/chartdata";

const App = () => {
  const [chartData, setChartData] = useState([]);
  ;
  useEffect(() => {
    // Fetch data from the API
    axios.get(API_URL).then((response) => {
      setChartData(response.data);
      
    });
  }, []);

 
  return (
    <div className="container">

<div className="magic-div">
        
          <span className="magical-text">
            Data Visualization
          </span>
      
      </div>
      <div className="chartContainer">
        <h2 className="headings">Bar Chart</h2>
        <BarChart width={400} height={300} data={chartData}>
          <Bar dataKey="marks" fill="#8884d8" />
          <Tooltip />
        </BarChart>
        <p className="tagline">Showing Marks</p>
      </div>

      <div className="chartContainer">
        <h2 className="headings">Pie Chart</h2>
        <PieChart width={400} height={300}>
          <Pie
            data={chartData}
            dataKey="age"
            nameKey="name"
            cx="50%"
            cy="50%"
            outerRadius={80}
            fill="#8884d8"
            label
          >
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={`#${index}${index}${index}`} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
        <p className="tagline">Showing Age</p>
      </div>

      <div className="chartContainer">
        <h2 className="headings">Scatter Chart</h2>
        <ScatterChart width={400} height={300}>
          <Scatter data={chartData} dataKey="marks" fill="#8884d8" />
          <Tooltip />
        </ScatterChart>
        <p className="tagline">Showing Marks</p>
      </div>

      <div className="chartContainer">
        <h2 className="headings">Line Chart</h2>
        <LineChart width={400} height={300} data={chartData}>
          <Line type="monotone" dataKey="age" stroke="#8884d8" />
          <Tooltip />
        </LineChart>
        <p className="tagline">Showing Age</p>
      </div>

      <div className="chartContainer">
        <h2 className="headings">Table</h2>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
              <th>Marks</th>
              <th>Roll No</th>
            </tr>
          </thead>
          <tbody>
            {chartData.map((entry, index) => (
              <tr key={index}>
                <td>{entry.name}</td>
                <td>{entry.age}</td>
                <td>{entry.marks}</td>
                <td>{entry.rollno}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="tagline">Showing Table Data</p>
      </div>
    </div>
  );
};

export default App;
